
import requests
import random
from config import API_KEY, FOREX_PAIRS

def get_forex_signals():
    results = {}
    for pair in FOREX_PAIRS:
        # Dummy simulation (replace with real API call + strategy logic)
        price = random.uniform(1.0, 1.5)
        signal_strength = random.randint(1, 6)
        signal = "BUY" if signal_strength > 3 else "SELL" if signal_strength < 3 else "HOLD"
        entry = round(price, 4)
        sl = round(entry - 0.0025, 4)
        tp = round(entry + 0.0050, 4)
        pnl = f"{random.choice(['+','-'])}${random.randint(0,100)}"

        results[pair] = {
            "signal": signal,
            "confidence": signal_strength,
            "entry": entry,
            "exit": f"TP: {tp}, SL: {sl}",
            "pnl": pnl
        }
    return results
