
import gradio as gr
from utils import get_forex_signals
from config import FOREX_PAIRS

def analyze_forex():
    results = get_forex_signals()
    output = ""
    for pair, info in results.items():
        output += f"📊 **{pair}**\n"
        output += f"Signal: {info['signal']}\n"
        output += f"Confidence: {info['confidence']} / 6\n"
        output += f"Entry: {info['entry']}\n"
        output += f"Exit: {info['exit']}\n"
        output += f"P&L: {info['pnl']}\n\n"
    return output

iface = gr.Interface(fn=analyze_forex, inputs=[], outputs="text", title="Tristarnold v1 EA")

if __name__ == "__main__":
    iface.launch()
